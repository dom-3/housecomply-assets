# V2.3a — Stage A state shape + initial factory + active tenancy detection

**Patch version:** V2.3a (first of three V2.3 sessions)
**Date:** 04 May 2026
**Source directive:** `V2_Stage_A_Port_Build_Chat_Directive.md` §6 V2.3
**Goal:** Lay the pure-state foundation for Stage A — section state
shapes, top-level `StageAState`, `createInitialState` factory, and the
active tenancy detection function. No reducer yet (V2.3b), no React
hook yet (V2.3c).

---

## V2.3 chunking plan

The directive estimates V2.3 at 2–3 days / ~50 tests. Splitting it
across three chat sessions due to context budget:

| Chunk | Scope | This deliverable |
|---|---|---|
| **V2.3a** (this) | State types + initial factory + active tenancy detection + tests for each | 56 tests added |
| **V2.3b** (next) | Reducer + Action union + per-section actions + validation logic + tests | ~30–40 tests planned |
| **V2.3c** (third) | `useStageAState` hook with boot-state machine + integration tests | ~10–15 tests planned |

After V2.3c the running total target is ~100 tests for V2.3 overall —
higher than the directive's "~50" because state-shape testing (covering
type-guarded seeding, mode inference, and edge cases) has more surface
area than the directive's estimate.

---

## What changed in V2.3a

### New files

| Path | Purpose |
|---|---|
| `src/domain/stageA/prefill-types.ts` | Airtable record shapes (PROPERTIES, ACCOUNTS, USERS, TENANCIES, LANDLORDS) used by the state factory and (in V2.4) the prefill service |
| `src/domain/stageA/active-tenancy.ts` | Pure function `detectActiveTenancies(allTenancies, propertyId, today)` per spec §6 + `formatTenancyLabel(t)` helper |
| `src/domain/stageA/__tests__/active-tenancy.test.ts` | 24 tests covering active flag, end-date logic, property linkage, ordering, today-arg flexibility, immutability, label formatting |
| `src/state/stageA.ts` | All 8 section state interfaces + top-level `StageAState` + `createInitialState({...})` factory + per-section `empty<Section>()` helpers |
| `src/state/__tests__/stageA.test.ts` | 32 tests covering empty factories, cold-start initial state, type-guarded property seeding, tenancy/landlord mode inference, agent split, prefill envelope preservation |

### Modified files

| Path | Change |
|---|---|
| `docs/v2-port-conflicts.md` | Appended V2.3a implementation status. C-6, C-7 (partial), C-8, C-9 now reflected in state shape. C-3 + C-4 reinforced by the type-guarded prefill seeding. |

### Unchanged

Everything from V2.1 + V2.2: routes, vercel.json, constants module,
all Stage B code. **No `package.json` change** — V2.2's test glob
already covers `src/state/__tests__/*.test.ts` and
`src/domain/stageA/__tests__/*.test.ts`.

---

## Design decisions

### 1. `today` injected into `detectActiveTenancies`

The directive's signature is two-arg: `detectActiveTenancies(allTenancies, propertyId): Tenancy[]`. To honour the directive's "pure function" emphasis (spec §6's end-date filter requires today's date), the actual signature takes `today` as a third arg accepting either `Date` or ISO string `YYYY-MM-DD`. The boot-state machine in V2.3c will pass it down from the hook layer.

### 2. Initial state factory accepts `active_tenancies` separately, not derived

`createInitialState` takes an `active_tenancies` array as input rather than computing it from `prefill.tenancies` internally. This decouples the factory from the active-detection logic, makes it trivially testable, and matches the boot-state machine pattern (the hook calls `detectActiveTenancies` once, stores result, passes to factory).

### 3. Property selects type-guarded at seed time

When seeding `property.property_type` etc. from `prefill.property.fields["Property Type"]`, the factory uses each `is<Name>` type guard from the constants module:
- Valid Airtable enum value → seed as that value
- Invalid / missing / wrong-case → seed as `""` (the inspector picks fresh)

This is defence-in-depth: if Airtable somehow holds a value outside our locked enums (manual edit, schema drift, legacy row), the form state stays type-safe. Conflicts C-3 (TENURE) and C-4 (5 property enums) are reinforced here.

### 4. State shape uses `T | ""` rather than `T | undefined`

Empty string `""` is the "not yet picked" sentinel for selects. `null` is the sentinel for date and number fields. This mirrors Stage B's pattern and keeps validation rules straightforward (`field === ""` for unfilled; `field === "Unknown"` for "user picked Unknown").

### 5. `schema_version` and `current_section` deliberately omitted

Per spec §11.2 (no draft autosave) and §3 (all 8 sections expanded), neither field is needed in v3.0. Adding them now would be premature scaffolding.

### 6. `is_dirty` and `is_submitting` are top-level, not in a UI substate

Stage B has a more elaborate `submission` state machine because of F48 / clarify resubmission / force-report routes. Stage A's submit flow is simpler (fire-and-forget), so two booleans cover everything needed for the beforeunload warning + double-submit prevention.

---

## Verification status

| Check | Result |
|---|---|
| **V2.3a unit tests** (`stageA.test.ts` + `active-tenancy.test.ts` only) | 56/56 pass, 0 fail, ~390ms |
| **Full repo test suite** (V2.1 + V2.2 + V2.3a, all node:test files) | 452/452 pass, 0 fail, ~3.3s |
| **Sandbox typecheck** (`tsc --project tsconfig.sandbox.json --noEmit`) | Clean exit 0 — no errors |
| **Production typecheck** — V2.3a net contribution | Zero new errors |
| **Production typecheck** — total error count | Same 7 pre-existing errors as in V2.2 (in unchanged Stage B `.tsx` files), none in V2.3a files |

The 7 pre-existing prod-typecheck errors are still on the May 2 zip
but not on your real GitHub HEAD (V2.2 deployed cleanly per your last
message). V2.3a doesn't touch those files, so it'll land cleanly
regardless.

---

## Test count delta

| Before V2.3a | After V2.3a |
|---|---|
| 396 node:test + 18 Vitest = **414** total | 452 node:test + 18 Vitest = **470** total |

Test count grew by 56 (24 in `active-tenancy.test.ts` + 32 in
`stageA.test.ts`). Locally verified on Node 22.22.

---

## How to apply this patch

Five new files, one modified doc. Drag-and-drop the unzipped folder
structure into the `housecomply-stage-b` repo via the GitHub web UI:

```
src/
  domain/stageA/
    active-tenancy.ts          [new]
    prefill-types.ts           [new]
    __tests__/
      active-tenancy.test.ts   [new]
  state/
    stageA.ts                  [new]
    __tests__/
      stageA.test.ts           [new]
docs/
  v2-port-conflicts.md         [modified — replaces existing]
  v2-3a-changes.md             [new — this file]
```

GitHub upload preview should show ~6 files. If it shows ~3, the nested
folder structure was lost — retry via the file picker.

Suggested commit message:

> V2.3a — Stage A state shape, initial factory, active tenancy detection.

Vercel will redeploy. Build runs `tsc --noEmit && vite build`; V2.3a's
own typecheck is clean and the existing 7 prod errors should already
be fixed on your HEAD.

---

## What to verify after Vercel deploys

| # | Check | How |
|---|---|---|
| 1 | Vercel build passes | Vercel deployment dashboard |
| 2 | Stage B route still works | `/inspect/stage-b?<test query>` loads as before |
| 3 | Stage A placeholder still loads | `/inspect/stage-a` renders the V2.1 placeholder card |
| 4 | (Optional) all 452 tests pass | `npm test` locally on Node 22.6+ |

V2.3a doesn't change any user-visible UI yet (Stage A is still the
placeholder); the deploy verification is just "still green".

---

## SL register applied to V2.3a

- **SL-15** (D2 wrapper reducer pattern): documented in `stageA.ts`
  as the V2.3b plan; the wrapper hook lands in V2.3c.
- **SL-16** (prod typecheck verified separately from sandbox):
  See verification status above. Both run; both clean for V2.3a.
- **SL-17** (verify HEAD on chat re-engagement): not re-engaging —
  same chat as V2.1 + V2.2.
- **SL-18** (chat namespace isolation): N/A.
- **SL-19** (sender-target tracking): commit tagged `V2.3a`.
- **SL-21** (no synthesis from memory when authoritative documents
  available): all field shapes + section structure ported from spec
  §4 + Webhook A Data Structure, not invented.

---

## What V2.3b picks up next

Per directive §6 V2.3.3 + V2.3.5:

- **Reducer** (`reducer(state, action): StageAState`) appended to
  `src/state/stageA.ts`. Per-section `update` actions plus picker-mode
  switches (`tenancy.pickExisting`, `tenancy.createNew`, etc.).
- **Validation logic** — pure function `validateState(state):
  { blocking: ValidationError[], warnings: ValidationWarning[] }`.
  Likely a sibling file `src/state/stageA-validation.ts` to keep
  `stageA.ts` from ballooning.
- **Tests** — reducer action coverage (every action type) + validation
  rule coverage (spec §5.1 blocking + §5.2 warnings).

Inputs needed for V2.3b chat:
- The post-V2.3a zip (re-download from GitHub once this push lands)
- `inspect-stage-a.js` validation function (lines ~800–1080) — not
  yet read, will be V2.3b's first action
- Phase 1 Spec v1.1 §5 (validation rules)

V2.3b is likely 1–2 chat sessions depending on complexity of the
validation rule surface (~20+ blocking rules + ~6 warning rules).
