# V2 port — spec / implementation conflicts

**Document version:** 1.0
**Date:** 04 May 2026
**Build phase:** V2.1 (route restructure)
**Authority:** CEO chat decisions of 04 May 2026 (this build chat session)
**Purpose:** Lock V2's behaviour for every place where Phase 1 Spec v1.1,
production `inspect-stage-a.js`, System Architecture §7.1, and the
Webhook A Data Structure disagree. Also serves as input to the v3.1
amendment cycle for the spec / Architecture documents.

---

## Conflict-resolution rule

Per V2 directive §2 and the risk register row 1, the rule is:

> The spec wins on **what the form should do**; the JS file wins on
> **which exact field names and enum values go in the payload**.

Where this rule doesn't cleanly resolve a conflict (transport mode is the
canonical example) the decision was escalated to CEO chat. CEO decisions
of 04 May 2026 are recorded inline below.

The shorthand `CA-class` (per directive §2) marks conflicts that are
implementation-vs-spec drift, to be promoted to v3.1 amendments without
re-litigation.

---

## C-1 · Transport mode (CORS + JSON vs no-cors + text/plain)

**Status:** Deferred to V2.6 implementation.

| Source | Value |
|---|---|
| V2 directive non-negotiable #3 | `mode: "no-cors"`, `Content-Type: "text/plain"` |
| Phase 1 Spec §2.4 | `mode: "no-cors"`, `Content-Type: "text/plain"` |
| Architecture §7.1 line 454 | `mode: "no-cors"`, `Content-Type: "text/plain"` |
| Webhook A Data Structure (Notes for Subsystem 2) | `mode: "no-cors"`, `Content-Type: "text/plain"` |
| Production `inspect-stage-a.js` lines 1099–1103 | **`CORS` + `application/json`** |

Four-against-one favours no-cors+text/plain on paper. But the production
form is currently working in Airtable with CORS+JSON, and Stage B already
ships its own webhook submission service (`src/services/submission.ts`)
which has its own answer.

**CEO decision (04 May 2026):** Match Stage B's existing
`services/submission.ts` pattern. V2.6 inspects what Stage B uses and
mirrors it in the new `services/stageASubmission.ts`. The V2.6 hand-back
to CEO chat reports which pattern Stage B uses, so the directive's
non-negotiable can be retroactively reconciled if needed.

**v3.1 amendment input:** Whichever pattern V2.6 ships, Phase 1 Spec
§2.4, Architecture §7.1, and the Data Structure doc need updating to
match. Until then, those three documents are inconsistent with at least
one shipping form.

---

## C-2 · `INSPECTION_TYPES` count (8 vs 9)

**Status:** Locked. Port 9 verbatim. CEO chat verifies Airtable enum
before V2.6 smoke test.

| Source | Count | Values |
|---|---|---|
| Phase 1 Spec §4 Section A | 8 | Start of tenancy / Mid-tenancy / End of tenancy / Annual / periodic / Pre-tenancy / pre-letting / Move-in / Move-out / Re-inspection (after works) |
| Webhook A Data Structure §inspection_type | 8 | (same as spec) |
| V2 directive §6 V2.2.1 | 9 | (matches impl) |
| Production `inspect-stage-a.js` lines 31–41 | 9 | spec's 8 PLUS `"Complaint follow-up"` |

**CEO decision (04 May 2026):** Port 9 values verbatim from the
implementation (`Complaint follow-up` included). CEO chat will verify via
Make MCP that the Airtable INSPECTIONS *Inspection Type* single-select
has all 9 options before V2.6 smoke test — if Airtable only has 8, a
`Complaint follow-up` submission will fail the downstream write.

**v3.1 amendment input:** Phase 1 Spec §4 Section A and Webhook A Data
Structure §inspection_type must list 9 values, not 8. CA-class.

---

## C-3 · `TENURE_VALUES` semantic mismatch

**Status:** Locked. Port implementation's 5 rental-status values.

| Source | Concept captured | Values |
|---|---|---|
| Phase 1 Spec §4 Section B | Property tenure (legal) | Freehold / Leasehold / Commonhold / Unknown |
| Production `inspect-stage-a.js` line 53 | Occupancy / rental status | Private rented / Owner occupied / Social Housing association / Void Unoccupied / Unknown |

This is not just label drift — the spec and the implementation are
capturing two different things. The Airtable PROPERTIES.Tenure field
matches the implementation (rental status), per the implementation's
A-27 comment ("Airtable-verified") at line 43.

**CEO decision (04 May 2026):** Port the implementation's 5 rental-status
values. The spec is drifted.

**v3.1 amendment input:** Phase 1 Spec §4 Section B *Tenure* row must be
rewritten to describe rental/occupancy status, not legal property tenure,
with the implementation's 5 values. CA-class. **High priority** — the
mislabelling of this field in the spec could mislead future spec readers
into reintroducing the freehold/leasehold concept.

---

## C-4 · Property single-select enum drift

**Status:** Locked. Port implementation values verbatim. v3.1 amendments.

The implementation's property single-select dropdowns are the locked
Airtable enums (per the A-27 implementation comment at line 43). Phase 1
Spec §4 Section B has earlier, drifted values.

| Enum | Spec values (drifted) | Implementation values (locked) |
|---|---|---|
| `PROPERTY_TYPE_VALUES` | 8: Detached / Semi / Terraced / End-terrace / Flat / Maisonette / Bungalow / Other | **10:** Terraced House / Semi-detached House / Detached House / End-terrace / Flat Purpose Built / Flat Conversion / Maisonette / Bungalow / HMO / Other |
| `CONSTRUCTION_TYPE_VALUES` | 10: Standard masonry / Cavity wall / Solid wall / Timber frame / Steel frame / System-built / Stone / Cob / Other / Unknown | **6:** Brick / Stone / Timber frame / Concrete / Mixed / Other |
| `AGE_BAND_VALUES` | 13 fine-grained bands (Pre-1900 / 1900–1929 / … / 2012+ / Unknown) | **5 coarse bands:** Pre-1900 / 1900–1944 / 1945–1979 / 1980–1999 / 2000 onwards |
| `LISTED_STATUS_VALUES` | 5: No / Grade I / Grade II / Grade II* / Unknown | **5:** Not listed / Grade I Listed / Grade II* Listed / Grade II Listed / Unknown (same count, different exact strings) |
| `HMO_STATUS_VALUES` | 3: Yes / No / Unknown | **3:** Yes / No / **Pending** (different third value) |

**CEO decision (04 May 2026):** Port implementation values verbatim
across all five enums.

**v3.1 amendment input:** Phase 1 Spec §4 Section B must be regenerated
from the implementation's enums (and ideally the Airtable schema export).
CA-class. The age-band reduction from 13 → 5 is the most consequential —
spec-style fine-grained age data isn't recoverable from the Airtable
field as configured.

---

## C-5 · `EICR_RESULT_VALUES` count (3 vs 5)

**Status:** Locked. Port 5 values.

| Source | Values |
|---|---|
| Phase 1 Spec §4 D2 | Satisfactory / Unsatisfactory / Limited (3) |
| Webhook A Data Structure (table A-04) | Same enum + Unknown + Not applicable (5) |
| Production `inspect-stage-a.js` line 59 | Satisfactory / Unsatisfactory / Limited / Unknown / Not applicable (5) |

Implementation + Data Structure agree (5). Spec is drifted (3).

**CEO decision (04 May 2026):** Port 5. CA-class.

---

## C-6 · Documentation sub-object field amendments (A-05, A-06, A-18)

**Status:** Locked. Port implementation + Data Structure shape.

Architecture §7.1 lines 499–503 are pre-amendment and lack several fields
that the implementation + Data Structure now require. These are the
amendment-tracked additions:

| Sub-object | Architecture §7.1 (pre) | Data Structure + impl (post) | Amendment |
|---|---|---|---|
| `gas` | available, issue_date, expiry_date, status | **at_property,** available, issue_date, expiry_date, status | A-05 |
| `fra` | date | **applicable,** date | A-18 |
| `asbestos` | date | **survey_held,** date | A-06 |
| `legionella` | date | **risk_assessment_held,** date | A-06 |

**CEO decision (04 May 2026):** Port Data Structure + implementation
shape. The Architecture doc is older.

**v3.1 amendment input:** Architecture §7.1 needs updating to include
these fields. CA-class. (Strictly: the directive's hierarchy ("the JS
file wins on field names") already covers this — flagged here for
completeness so the v3.1 cycle catches it.)

---

## C-7 · Tenancy date field name (`tenancy_start_date` vs `occupation_start_date`)

**Status:** Locked. Use `occupation_start_date` (Data Structure + impl).

| Source | Field name |
|---|---|
| Architecture §7.1 line 487 | `tenancy.tenancy_start_date` |
| Webhook A Data Structure | `tenancy.occupation_start_date` (per A-01) |
| Production `inspect-stage-a.js` line 1194 | `tenancy.occupation_start_date` |

A-01 amendment renamed the field. Architecture is pre-amendment.

**v3.1 amendment input:** Architecture §7.1 must use
`occupation_start_date` to align with A-01.

---

## C-8 · `epc.certificate_url` empty string vs null

**Status:** Locked. Empty string `""`.

| Source | Value in v3.0 |
|---|---|
| Phase 1 Spec §4 D1 | `null` ("forward compatible — Subsystem 8 will populate") |
| Webhook A Data Structure (sample JSON) | `""` (empty string) |
| Production `inspect-stage-a.js` line 1207 | `""` (empty string) |

Trivial drift, but worth recording so the V2.6 payload builder uses
empty string consistently.

**v3.1 amendment input:** Phase 1 Spec §4 D1 should say "empty string"
not `null`.

---

## C-9 · `deposit_protected_date` — UI-only, not in payload

**Status:** Locked. UI field only; not in payload.

The implementation has a `deposit_protected_date` form field used solely
for the §5.2 "deposit protected within 30 days?" warning calculation
(line 531, marked "for warning check, not submitted"). The Data
Structure does not include it. Phase 1 Spec §4 Section E lists it as a
field without explicitly saying whether it's submitted.

**CEO decision implicit:** Match implementation + Data Structure.
`deposit_protected_date` is captured in form state for the warning
computation only, and is *not* included in the Webhook A payload.

**v3.1 amendment input:** Phase 1 Spec §4 Section E should explicitly
mark `deposit_protected_date` as UI-only / not submitted.

---

## Summary table

| ID | Conflict | V2 decision | v3.1 amendment scope |
|---|---|---|---|
| C-1 | Transport mode | Defer to V2.6 (match Stage B) | Spec §2.4, Arch §7.1, DS Notes |
| C-2 | `INSPECTION_TYPES` 8 vs 9 | Port 9 (verify Airtable) | Spec §4.A, DS §inspection_type |
| C-3 | `TENURE_VALUES` semantic | Port impl (rental status, 5) | Spec §4.B *Tenure* row |
| C-4 | Property enum drift (5 enums) | Port impl verbatim | Spec §4.B (regenerate from Airtable) |
| C-5 | `EICR_RESULT_VALUES` 3 vs 5 | Port 5 | Spec §4.D2 |
| C-6 | Documentation sub-object fields | Port impl + DS shape | Arch §7.1 |
| C-7 | Tenancy date field name | `occupation_start_date` | Arch §7.1 line 487 |
| C-8 | `epc.certificate_url` `""` vs `null` | Empty string | Spec §4.D1 |
| C-9 | `deposit_protected_date` in payload? | UI-only, not submitted | Spec §4.E |

All C-2 through C-9 are CA-class — implementation drift to be promoted
to v3.1 amendments without re-litigation.

---

## Items NOT in this register

The following were *not* found to conflict during V2.1 orientation, and
the spec / implementation / Data Structure agree:

- `EPC_RATING_VALUES` (7: A–G)
- `EPC_EXEMPTION_TYPES` (8 controlled list values)
- `DEPOSIT_SCHEMES` (4: DPS / MyDeposits / TDS / Other)
- `CONTRACT_TYPE_VALUES` (4: Periodic Standard / Fixed-Term Standard / Joint / Other)
- Yes/No payload value lowercasing (`"yes"` / `"no"` / `"unknown"`)
- `FORM_VERSION = "HouseComply-V3-StageA"` and `STAGE = "A"` payload constants
- `_meta` block field set
- `landlord` and `agent` payload field sets

These are stable across the four sources and need no decisions.

---

## Outstanding (not yet read in this orientation)

V2.1 orientation deliberately scoped to enums, payload shape, transport,
and Stage B HEAD. The following weren't fully read and may surface
additional drift in subsequent V2.X chats:

- `inspect-styles.css` — design-token reconciliation (V2.5 input)
- Architecture §10 (JS conventions), §11 (GHL routing), §12 (Stage A/B
  split) — likely informational rather than constraint-changing for V2,
  but should be read at V2.2 / V2.4
- `inspect-stage-a.js` agent population logic (lines ~580–620), validation
  function, prefill fetch logic — V2.3 / V2.4 / V2.5 inputs

If any of those reveal further conflicts, append to this register as
C-10, C-11, etc.

---

## Implementation status log

Running log of where each conflict has been locked into code. Updated as
each V2.X workstream lands.

### As of V2.2 (04 May 2026, this build chat session)

| ID | Conflict | Status | Locked in |
|---|---|---|---|
| C-1 | Transport mode | Pending | V2.6 (Stage A submission service) |
| C-2 | `INSPECTION_TYPES` 9 vs 8 | **✅ Implemented** | `src/domain/stageA/constants.ts` — 9 values + length-locking test |
| C-3 | `TENURE_VALUES` semantic | **✅ Implemented** | `src/domain/stageA/constants.ts` — 5 rental-status values + test asserting absence of legal-tenure terms |
| C-4 | Property enum drift (5 enums) | **✅ Implemented** | `src/domain/stageA/constants.ts` — all 5 enums + length + exact-strings tests |
| C-5 | `EICR_RESULT_VALUES` 5 vs 3 | **✅ Implemented** | `src/domain/stageA/constants.ts` — 5 values + test asserting Unknown / Not applicable inclusion |
| C-6 | Documentation sub-object fields | Pending | V2.3 (state shape) + V2.6 (payload builder) |
| C-7 | Tenancy date field name | Pending | V2.6 (payload builder) |
| C-8 | `epc.certificate_url` `""` vs `null` | Pending | V2.6 (payload builder) |
| C-9 | `deposit_protected_date` in payload? | Pending | V2.3 (state shape — UI-only) + V2.6 (payload exclusion) |

### V2.2 also locked-in (no spec conflict, but locked behaviour)

The constants module also adds `FORM_VERSION`, `STAGE`, and
`COUNTRY_DEFAULT` — payload-level constants required for V2.6's payload
builder. These are sourced from `inspect-stage-a.js` lines 27–29 and
match all four authority documents. No conflict.

The four lowercase YN value sets (`YN_ONLY`, `YN_NA`, `YN_UNKNOWN`,
`YN_NA_UNKNOWN`) are also locked, with a cross-cutting test asserting
every value is strictly lowercase per V2 directive non-negotiable #4
("never `'Yes'`, never `true`, never `1`").

### Drift gotchas locked in test

Two character-encoding subtleties caught by V2.2's test suite:

- **`AGE_BAND_VALUES`** uses Unicode en-dash `–` (U+2013) in the band
  ranges (e.g. `1900–1944`). ASCII hyphen would break the Airtable
  enum match silently. Test: `AGE_BAND_VALUES (Conflict C-4: 5 values,
  en-dash gotcha) → uses Unicode en-dash (U+2013) in the band ranges,
  not ASCII hyphen`.
- **`EPC_EXEMPTION_TYPES`** "Other — describe" uses Unicode em-dash `—`
  (U+2014). Test: `EPC_EXEMPTION_TYPES (8 values, em-dash gotcha) →
  'Other — describe' uses Unicode em-dash (U+2014), not ASCII hyphen`.

These tests will fail loudly if any future edit converts the dashes to
ASCII hyphens (the easiest accidental "fix" to make).

### As of V2.3a (04 May 2026, this build chat session)

V2.3a delivers the first chunk of state management: state shape +
initial state factory + active tenancy detection. No reducer yet
(V2.3b), no React hook yet (V2.3c). Tests added: 56. Total now: 452.

| ID | Conflict | Status update | Locked in |
|---|---|---|---|
| C-1 | Transport mode | Pending | V2.6 (Stage A submission service) |
| C-2 | `INSPECTION_TYPES` 9 vs 8 | ✅ V2.2 | constants module |
| C-3 | `TENURE_VALUES` semantic | ✅ V2.2 + V2.3a | constants module + initial state factory's `seedPropertyFromPrefill` rejects spec-style "Freehold" via type guard |
| C-4 | Property enum drift (5 enums) | ✅ V2.2 + V2.3a | constants module + state factory uses each `is<Name>` type guard to reject out-of-Airtable values during prefill seeding |
| C-5 | `EICR_RESULT_VALUES` 5 vs 3 | ✅ V2.2 | constants module |
| C-6 | Documentation sub-object fields | ✅ V2.3a (state shape) | `DocumentationState` includes A-05 `gas.at_property`, A-18 `fra.applicable`, A-06 `asbestos.survey_held` and `legionella.risk_assessment_held` — V2.6 payload builder will mirror |
| C-7 | Tenancy date field name | Partial — V2.3a state | `TenancyState.occupation_start_date` field present (name matches Data Structure A-01). V2.6 payload builder must map this to the correct payload key. |
| C-8 | `epc.certificate_url` `""` vs `null` | ✅ V2.3a | `EpcState.certificate_url` is `string` (always `""` in v3.0); state factory + `emptyDocumentation()` initialise as `""`. V2.6 will preserve the empty string into the payload. |
| C-9 | `deposit_protected_date` in payload? | ✅ V2.3a (state shape) | `FinancialState.deposit_protected_date` present as a UI-only field. V2.6 payload builder MUST exclude it from the wire payload — explicitly noted in the field's JSDoc. |

### V2.3a additions to the no-conflict register

The state shape also locks-in:

- **`schema_version` deliberately omitted.** Stage A has no draft
  persistence in v3.0 (locked decision spec §11.2). Will be added in
  v3.1+ if persistence lands.
- **`current_section` deliberately omitted.** All 8 sections render
  expanded by default (spec §3); no single-section navigation state
  needed.
- **No `submission` state machine in V2.3a.** Stage A's submit is
  fire-and-forget (spec §8.1); only `is_submitting` flag is needed,
  and that's part of the top-level state. V2.6 builds the actual
  submit flow.
- **`detectActiveTenancies(allTenancies, propertyId, today)` extends
  the directive's two-arg signature** with a `today` injection
  parameter to keep the function pure (no clock access). See §V2.3.4
  in the directive — this is a design refinement consistent with the
  "pure function" emphasis.
