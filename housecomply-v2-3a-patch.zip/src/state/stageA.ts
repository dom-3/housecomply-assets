/**
 * Stage A state — the form's in-progress draft.
 *
 * Mirrors the §7 Webhook A payload shape but represents work-in-progress:
 * select fields use empty string `""` as the "not yet picked" sentinel
 * (distinct from legitimate values like `"Unknown"`); date/number fields
 * use `null`. Validation (V2.3b) rejects `""` for required fields and
 * accepts `"Unknown"` as a valid submission per spec §3.1
 * ("required-or-Unknown rule").
 *
 * V2.3a scope: types + initial state factory + active tenancy detection.
 * V2.3b will add the reducer + Action union + per-section update actions.
 * V2.3c will add the `useStageAState` hook (with boot state machine).
 *
 * Pattern reference: Stage B's `src/state/inspection.ts`. Same shape:
 *   - exported state interface
 *   - empty<Section> factories for each section
 *   - top-level `createInitialState({...})` factory taking injected `now`
 *
 * Notably absent from Stage A vs Stage B:
 *   - No `schema_version` — Stage A has no draft persistence in v3.0
 *     (locked decision spec §11.2). Will be added in v3.1+ if persistence
 *     lands.
 *   - No `current_section` — all 8 sections render expanded by default
 *     per spec §3, so there's no single-section navigation state.
 *   - No `submission` state machine — Stage A's submit is fire-and-forget
 *     (spec §8.1); the only UI flag needed is `is_submitting`. V2.6
 *     handles the submit flow.
 *
 * Source directive: V2 directive §6 V2.3.1, V2.3.2
 * Spec citations: §3.1 (required-or-Unknown), §4 (per-section field set),
 *   §11.1 (address read-only), §11.6 (agent split)
 */

import type {
  InspectionType,
  PropertyType,
  ConstructionType,
  AgeBand,
  ListedStatus,
  Tenure,
  HmoStatus,
  ContractType,
  EpcRating,
  EicrResult,
  DepositScheme,
  YnOnly,
  YnNa,
  YnUnknown,
  YnNaUnknown,
} from "../domain/stageA/constants.ts";
import type {
  StageAPrefillData,
  PropertyRecord,
  AccountRecord,
  UserRecord,
} from "../domain/stageA/prefill-types.ts";
import {
  isPropertyType,
  isConstructionType,
  isAgeBand,
  isListedStatus,
  isTenure,
  isHmoStatus,
  isYnUnknown,
} from "../domain/stageA/constants.ts";

/* ============================================================
 * URL parameters
 * ============================================================ */

export interface StageAUrlParams {
  account_id: string;
  user_id: string;
  property_id: string;
}

/* ============================================================
 * Section A — Inspection context
 * Spec §4 Section A
 * ============================================================ */

export interface InspectionContextState {
  /** Empty string = not yet picked; required for submit. */
  inspection_type: InspectionType | "";
  /** ISO date `YYYY-MM-DD`. Defaults to today on initial state. */
  inspection_date: string;
}

export function emptyInspectionContext(today: string): InspectionContextState {
  return { inspection_type: "", inspection_date: today };
}

/* ============================================================
 * Section B — Property
 * Spec §4 Section B; address fields are read-only and live in
 * `prefill.property` rather than the editable state.
 * ============================================================ */

export interface PropertyState {
  property_type: PropertyType | "";
  construction_type: ConstructionType | "";
  age_band: AgeBand | "";
  listed_status: ListedStatus | "";
  /** "yes" / "no" / "unknown". */
  conservation_area: YnUnknown | "";
  tenure: Tenure | "";
  hmo_status: HmoStatus | "";
  num_bedrooms: number | null;
}

export function emptyProperty(): PropertyState {
  return {
    property_type: "",
    construction_type: "",
    age_band: "",
    listed_status: "",
    conservation_area: "",
    tenure: "",
    hmo_status: "",
    num_bedrooms: null,
  };
}

/* ============================================================
 * Section C — Tenancy
 * Spec §4 Section C; picker pattern (existing or new)
 * ============================================================ */

export type TenancyMode = "pick_existing" | "create_new";

export interface TenancyState {
  /** Picker selection. Inferred-defaulted by initial state factory based
   *  on whether any active tenancies exist. */
  mode: TenancyMode;
  /** Set when mode = pick_existing AND inspector has chosen one. */
  selected_tenancy_id: string | null;

  occupation_contract_type: ContractType | "";
  /** ISO date — when the contract was signed. */
  contract_start_date: string | null;
  /** ISO date — per A-01, when the contract holder takes possession.
   *  The 14-day Written Statement deadline calculates from this. */
  occupation_start_date: string | null;
  /** ISO date — empty for periodic / open tenancies. */
  contract_end_date: string | null;
  written_statement_prepared: YnUnknown | "";
  /** Required only if `written_statement_prepared = "yes"`. */
  written_statement_served_date: string | null;
  inventory_signed: YnNaUnknown | "";
  num_tenants: number | null;
  /** Comma-separated free text. */
  tenant_names: string;
}

export function emptyTenancy(mode: TenancyMode): TenancyState {
  return {
    mode,
    selected_tenancy_id: null,
    occupation_contract_type: "",
    contract_start_date: null,
    occupation_start_date: null,
    contract_end_date: null,
    written_statement_prepared: "",
    written_statement_served_date: null,
    inventory_signed: "",
    num_tenants: null,
    tenant_names: "",
  };
}

/* ============================================================
 * Section D — Documentation status (8 sub-sections D1–D8)
 * Spec §4 Section D
 * ============================================================ */

export interface EpcState {
  available: YnUnknown | "";
  rating: EpcRating | "";
  date: string | null;
  /** Always empty in v3.0 per A-07. Forward-compatible — Subsystem 8
   *  will populate post-v3.0 file uploads. */
  certificate_url: string;
  /** Free-text-friendly: controlled list values OR free text via
   *  "Other — describe". Validated against EPC_EXEMPTION_TYPES at
   *  submit time (V2.3b validation). */
  exemption_type: string;
}

export interface EicrState {
  available: YnUnknown | "";
  issue_date: string | null;
  expiry_date: string | null;
  result: EicrResult | "";
  /** Per spec §3.2: "Pass | Fail | Advisory | Missing | Unknown |
   *  Not checked | Not applicable". Loose-typed for V2.3a; V2.3b
   *  may tighten via a STATUS_VALUES constant if validation requires. */
  status: string;
}

export interface EicState {
  /** "Not applicable" is a first-class option here per spec §4 D3. */
  available: YnNaUnknown | "";
  issue_date: string | null;
}

export interface GasState {
  /** Spec amendment A-05 — gates gas-applicability. */
  at_property: YnUnknown | "";
  available: YnUnknown | "";
  issue_date: string | null;
  expiry_date: string | null;
  status: string;
}

export interface FraState {
  /** Spec amendment A-18. */
  applicable: YnUnknown | "";
  date: string | null;
}

export interface AsbestosState {
  /** Spec amendment A-06. */
  survey_held: YnNaUnknown | "";
  date: string | null;
}

export interface RadonState {
  checked: YnUnknown | "";
  date: string | null;
}

export interface LegionellaState {
  /** Spec amendment A-06. */
  risk_assessment_held: YnUnknown | "";
  date: string | null;
}

export interface DocumentationState {
  epc: EpcState;
  eicr: EicrState;
  eic: EicState;
  gas: GasState;
  fra: FraState;
  asbestos: AsbestosState;
  radon: RadonState;
  legionella: LegionellaState;
}

export function emptyDocumentation(): DocumentationState {
  return {
    epc: { available: "", rating: "", date: null, certificate_url: "", exemption_type: "" },
    eicr: { available: "", issue_date: null, expiry_date: null, result: "", status: "" },
    eic: { available: "", issue_date: null },
    gas: { at_property: "", available: "", issue_date: null, expiry_date: null, status: "" },
    fra: { applicable: "", date: null },
    asbestos: { survey_held: "", date: null },
    radon: { checked: "", date: null },
    legionella: { risk_assessment_held: "", date: null },
  };
}

/* ============================================================
 * Section E — Financial / regulatory
 * Spec §4 Section E
 * ============================================================ */

export interface FinancialState {
  deposit_amount: number | null;
  deposit_protected_within_30_days: YnUnknown | "";
  deposit_scheme: DepositScheme | "";
  deposit_reference: string;
  /** Per Conflict C-9: UI-only field for the §5.2 30-day-protection
   *  warning calculation. NOT included in the Webhook A payload.
   *  V2.6 payload builder must exclude this. */
  deposit_protected_date: string | null;
  prescribed_information_issued: YnUnknown | "";
  /** YnNa not YnUnknown — spec §4 Section E uses "Yes / No / Not applicable". */
  tpo_membership_disclosed: YnNa | "";
  complaints_procedure_issued: YnUnknown | "";
}

export function emptyFinancial(): FinancialState {
  return {
    deposit_amount: null,
    deposit_protected_within_30_days: "",
    deposit_scheme: "",
    deposit_reference: "",
    deposit_protected_date: null,
    prescribed_information_issued: "",
    tpo_membership_disclosed: "",
    complaints_procedure_issued: "",
  };
}

/* ============================================================
 * Section F — Landlord
 * Spec §4 Section F; picker pattern (existing or new)
 * ============================================================ */

export type LandlordMode = "pick_existing" | "create_new";

export interface LandlordState {
  mode: LandlordMode;
  selected_landlord_id: string | null;
  name: string;
  rsw_registration_number: string;
  email: string;
  phone: string;
}

export function emptyLandlord(mode: LandlordMode): LandlordState {
  return {
    mode,
    selected_landlord_id: null,
    name: "",
    rsw_registration_number: "",
    email: "",
    phone: "",
  };
}

/* ============================================================
 * Section G — Agent
 * Spec §4 Section G; auto-populated from ACCOUNTS (company-level) +
 * USERS (inspector-level). Locked decision §11.6 splits these between
 * tables for the patch-back behaviour.
 * ============================================================ */

export interface AgentState {
  /** Inspector name — sourced from USERS.Name. Edits flow back to USERS. */
  name: string;
  /** Account / agency name — sourced from ACCOUNTS.Company Name. */
  company: string;
  /** Account RSW licence — sourced from ACCOUNTS.RSW Licence. */
  rsw_licence_number: string;
  /** Inspector qualifications — sourced from USERS.Professional Body
   *  Memberships (per §13.2 schema addition). Free text. */
  professional_body_memberships: string;
}

export function emptyAgent(): AgentState {
  return {
    name: "",
    company: "",
    rsw_licence_number: "",
    professional_body_memberships: "",
  };
}

/* ============================================================
 * Top-level Stage A state
 * ============================================================ */

export interface StageAState {
  url_params: StageAUrlParams;
  prefill: StageAPrefillData;
  inspection_context: InspectionContextState;
  property: PropertyState;
  tenancy: TenancyState;
  documentation: DocumentationState;
  financial: FinancialState;
  landlord: LandlordState;
  agent: AgentState;
  /** Touched-since-load flag for the beforeunload warning (spec §2.5). */
  is_dirty: boolean;
  /** Submit-in-flight flag — primary defence against double-submit per
   *  spec §8.2 idempotency. */
  is_submitting: boolean;
  /** ISO timestamp when state was first created. */
  draft_started_at: string;
  /** ISO timestamp of last meaningful state change. Updated by reducer
   *  (V2.3b). */
  last_modified_at: string;
}

/* ============================================================
 * Initial state factory
 *
 * Builds the seeded StageAState from URL params + prefill data + clock
 * inputs. Pure function — `now` and `today` are injected, not read from
 * the system clock.
 *
 * Seeding rules (per spec §2.3 step 6 + §4):
 *   - inspection_context.inspection_date = today
 *   - property.* seeded from prefill.property when valid (type-guarded)
 *   - tenancy.mode = pick_existing if active tenancies exist, else create_new
 *   - landlord.mode = pick_existing if any landlords exist, else create_new
 *   - agent.name from prefill.user.Name
 *   - agent.company / rsw_licence_number from prefill.account
 *   - agent.professional_body_memberships from prefill.user
 *   - is_dirty / is_submitting = false
 *
 * Field-level seeding for property:
 *   We DON'T seed each property select directly to its raw Airtable
 *   value, because Airtable values may not match the locked enum (e.g.
 *   if Airtable holds a value that isn't in our PROPERTY_TYPE_VALUES,
 *   we'd corrupt the form's typed state). Instead we type-guard each
 *   value: if it's a valid enum member, seed it; if not, seed "" so
 *   the inspector picks fresh. This preserves the "no magic strings"
 *   discipline.
 * ============================================================ */

export interface InitialStateArgs {
  url_params: StageAUrlParams;
  prefill: StageAPrefillData;
  /** ISO timestamp for draft_started_at / last_modified_at. */
  now: string;
  /** ISO date `YYYY-MM-DD` for inspection_date default + active tenancy
   *  filter (V2.3b validation may also use it). */
  today: string;
  /** Pre-filtered active tenancies for this property (output of
   *  detectActiveTenancies). Decoupled here so the factory doesn't
   *  re-run the filter — the boot-state machine does it once and
   *  passes the result down. Defaults to []. */
  active_tenancies?: readonly { id: string }[];
}

export function createInitialState(args: InitialStateArgs): StageAState {
  const {
    url_params,
    prefill,
    now,
    today,
    active_tenancies = [],
  } = args;

  const tenancyMode: TenancyMode =
    active_tenancies.length > 0 ? "pick_existing" : "create_new";

  const landlordMode: LandlordMode =
    prefill.landlords.length > 0 ? "pick_existing" : "create_new";

  return {
    url_params,
    prefill,
    inspection_context: emptyInspectionContext(today),
    property: seedPropertyFromPrefill(prefill.property),
    tenancy: emptyTenancy(tenancyMode),
    documentation: emptyDocumentation(),
    financial: emptyFinancial(),
    landlord: emptyLandlord(landlordMode),
    agent: seedAgentFromPrefill(prefill.account, prefill.user),
    is_dirty: false,
    is_submitting: false,
    draft_started_at: now,
    last_modified_at: now,
  };
}

/* ============================================================
 * Internal seed helpers
 * ============================================================ */

/**
 * Reads each property select from the PROPERTIES row, type-guarded
 * against the locked enum. Invalid / missing values seed as `""` so
 * the inspector picks fresh. `num_bedrooms` is taken as-is if numeric.
 */
function seedPropertyFromPrefill(prop: PropertyRecord | null): PropertyState {
  if (prop == null) return emptyProperty();
  const f = prop.fields;
  return {
    property_type: isPropertyType(f["Property Type"]) ? f["Property Type"] : "",
    construction_type: isConstructionType(f["Construction Type"])
      ? f["Construction Type"]
      : "",
    age_band: isAgeBand(f["Age Band"]) ? f["Age Band"] : "",
    listed_status: isListedStatus(f["Listed Status"]) ? f["Listed Status"] : "",
    conservation_area: isYnUnknown(f["Conservation Area"])
      ? f["Conservation Area"]
      : "",
    tenure: isTenure(f.Tenure) ? f.Tenure : "",
    hmo_status: isHmoStatus(f["HMO Status"]) ? f["HMO Status"] : "",
    num_bedrooms:
      typeof f["Number of Bedrooms"] === "number" && f["Number of Bedrooms"] >= 0
        ? f["Number of Bedrooms"]
        : null,
  };
}

/**
 * Per spec §11.6: agent split between ACCOUNTS-sourced (company,
 * rsw_licence_number) and USERS-sourced (name, professional_body_
 * memberships). Each source independently null-safe.
 */
function seedAgentFromPrefill(
  account: AccountRecord | null,
  user: UserRecord | null,
): AgentState {
  return {
    name: user?.fields.Name?.trim() ?? "",
    company: account?.fields["Company Name"]?.trim() ?? "",
    rsw_licence_number: account?.fields["RSW Licence"]?.trim() ?? "",
    professional_body_memberships:
      user?.fields["Professional Body Memberships"]?.trim() ?? "",
  };
}

/* ============================================================
 * V2.3b will append from here:
 *   - Action union type
 *   - reducer(state, action) function
 *   - per-section action creators
 *   - last_modified_at touch helper
 *
 * V2.3c will add (in src/state/useStageAState.ts):
 *   - useStageAState hook with boot-state machine
 *   - integration with detectActiveTenancies + prefill service
 * ============================================================ */

// Re-export types referenced by callers so V2.5 components don't have
// to import from both stageA.ts and prefill-types.ts to get the full
// state surface.
export type {
  StageAPrefillData,
  PropertyRecord,
  AccountRecord,
  UserRecord,
  TenancyRecord,
  LandlordRecord,
} from "../domain/stageA/prefill-types.ts";

// Re-export YnOnly so consumers don't need to grab it separately.
// (YnOnly isn't currently used in StageAState fields, but is included
// for completeness in case V2.3b's reducer or V2.5 components want it.)
export type { YnOnly };
