/**
 * Stage A state shape + initial factory tests.
 *
 * Coverage:
 *   - empty<Section> factories produce expected shapes
 *   - createInitialState with empty prefill (cold start)
 *   - createInitialState with full prefill (seeded)
 *   - Property field type-guarding (valid → seed, invalid → "")
 *   - Tenancy mode inference (active_tenancies → pick_existing)
 *   - Landlord mode inference (prefill.landlords → pick_existing)
 *   - Agent split (ACCOUNTS-sourced vs USERS-sourced) per spec §11.6
 *   - num_bedrooms numeric validation
 *   - is_dirty / is_submitting defaults
 *   - draft_started_at / last_modified_at injection
 *
 * Pure-state tests only — V2.3b will add reducer tests, V2.3c will add
 * hook + integration tests.
 */

import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  createInitialState,
  emptyInspectionContext,
  emptyProperty,
  emptyTenancy,
  emptyDocumentation,
  emptyFinancial,
  emptyLandlord,
  emptyAgent,
  type StageAState,
} from "../stageA.ts";
import {
  emptyPrefillData,
  type StageAPrefillData,
  type PropertyRecord,
  type AccountRecord,
  type UserRecord,
  type LandlordRecord,
} from "../../domain/stageA/prefill-types.ts";

const URL_PARAMS = {
  account_id: "recAccount1",
  user_id: "recUser1",
  property_id: "recProperty1",
};
const NOW = "2026-05-04T10:00:00.000Z";
const TODAY = "2026-05-04";

/* ============================================================
 * Empty section factories
 * ============================================================ */

describe("empty section factories", () => {
  it("emptyInspectionContext sets inspection_date to today, inspection_type empty", () => {
    const s = emptyInspectionContext(TODAY);
    assert.deepEqual(s, { inspection_type: "", inspection_date: TODAY });
  });

  it("emptyProperty has all selects empty and num_bedrooms null", () => {
    assert.deepEqual(emptyProperty(), {
      property_type: "",
      construction_type: "",
      age_band: "",
      listed_status: "",
      conservation_area: "",
      tenure: "",
      hmo_status: "",
      num_bedrooms: null,
    });
  });

  it("emptyTenancy('pick_existing') sets mode and leaves all fields empty/null", () => {
    const s = emptyTenancy("pick_existing");
    assert.equal(s.mode, "pick_existing");
    assert.equal(s.selected_tenancy_id, null);
    assert.equal(s.occupation_contract_type, "");
    assert.equal(s.contract_start_date, null);
    assert.equal(s.tenant_names, "");
  });

  it("emptyTenancy('create_new') sets mode = create_new", () => {
    assert.equal(emptyTenancy("create_new").mode, "create_new");
  });

  it("emptyDocumentation has all 8 sub-sections with empty values", () => {
    const d = emptyDocumentation();
    assert.equal(d.epc.available, "");
    assert.equal(d.epc.certificate_url, ""); // C-8: empty string, not null
    assert.equal(d.eicr.available, "");
    assert.equal(d.eic.available, "");
    assert.equal(d.gas.at_property, "");
    assert.equal(d.fra.applicable, "");
    assert.equal(d.asbestos.survey_held, "");
    assert.equal(d.radon.checked, "");
    assert.equal(d.legionella.risk_assessment_held, "");
  });

  it("emptyFinancial includes deposit_protected_date (UI-only, C-9)", () => {
    const f = emptyFinancial();
    assert.equal(f.deposit_amount, null);
    assert.equal(f.deposit_protected_date, null);
    assert.equal(f.tpo_membership_disclosed, ""); // YnNa, not YnUnknown
  });

  it("emptyLandlord('pick_existing') sets mode", () => {
    const s = emptyLandlord("pick_existing");
    assert.equal(s.mode, "pick_existing");
    assert.equal(s.name, "");
    assert.equal(s.email, "");
  });

  it("emptyAgent has all string fields blank", () => {
    assert.deepEqual(emptyAgent(), {
      name: "",
      company: "",
      rsw_licence_number: "",
      professional_body_memberships: "",
    });
  });
});

/* ============================================================
 * createInitialState — empty prefill (cold start)
 * ============================================================ */

describe("createInitialState — empty prefill (cold start)", () => {
  function build(): StageAState {
    return createInitialState({
      url_params: URL_PARAMS,
      prefill: emptyPrefillData(),
      now: NOW,
      today: TODAY,
    });
  }

  it("returns top-level state with url_params and timestamps set", () => {
    const s = build();
    assert.deepEqual(s.url_params, URL_PARAMS);
    assert.equal(s.draft_started_at, NOW);
    assert.equal(s.last_modified_at, NOW);
  });

  it("inspection_date defaults to today, inspection_type empty", () => {
    const s = build();
    assert.equal(s.inspection_context.inspection_date, TODAY);
    assert.equal(s.inspection_context.inspection_type, "");
  });

  it("property state is fully empty when prefill.property is null", () => {
    const s = build();
    assert.deepEqual(s.property, emptyProperty());
  });

  it("tenancy mode = create_new when no active tenancies", () => {
    const s = build();
    assert.equal(s.tenancy.mode, "create_new");
  });

  it("landlord mode = create_new when prefill.landlords is empty", () => {
    const s = build();
    assert.equal(s.landlord.mode, "create_new");
  });

  it("agent state is fully empty when prefill.account and prefill.user are null", () => {
    const s = build();
    assert.deepEqual(s.agent, emptyAgent());
  });

  it("is_dirty and is_submitting default to false", () => {
    const s = build();
    assert.equal(s.is_dirty, false);
    assert.equal(s.is_submitting, false);
  });
});

/* ============================================================
 * createInitialState — property seeding from prefill
 * ============================================================ */

describe("createInitialState — property seeding (type-guarded)", () => {
  function withPropertyFields(fields: PropertyRecord["fields"]): StageAState {
    return createInitialState({
      url_params: URL_PARAMS,
      prefill: {
        ...emptyPrefillData(),
        property: { id: URL_PARAMS.property_id, fields },
      },
      now: NOW,
      today: TODAY,
    });
  }

  it("seeds valid property_type from PROPERTIES row", () => {
    const s = withPropertyFields({ "Property Type": "Terraced House" });
    assert.equal(s.property.property_type, "Terraced House");
  });

  it("rejects invalid property_type value (seeds as '')", () => {
    // 'Detached' (without 'House') is a spec-style value not in the
    // Airtable enum. Type guard rejects it.
    const s = withPropertyFields({ "Property Type": "Detached" });
    assert.equal(s.property.property_type, "");
  });

  it("seeds valid construction_type, rejects invalid", () => {
    const valid = withPropertyFields({ "Construction Type": "Brick" });
    assert.equal(valid.property.construction_type, "Brick");

    const invalid = withPropertyFields({
      "Construction Type": "Standard masonry", // spec value, not in Airtable
    });
    assert.equal(invalid.property.construction_type, "");
  });

  it("seeds valid age_band with en-dash", () => {
    const s = withPropertyFields({ "Age Band": "1900–1944" });
    assert.equal(s.property.age_band, "1900–1944");
  });

  it("rejects ASCII-hyphen age_band variant", () => {
    const s = withPropertyFields({ "Age Band": "1900-1944" });
    assert.equal(s.property.age_band, "");
  });

  it("seeds tenure (rental status, not legal tenure per C-3)", () => {
    const valid = withPropertyFields({ Tenure: "Private rented" });
    assert.equal(valid.property.tenure, "Private rented");

    const invalid = withPropertyFields({ Tenure: "Freehold" }); // spec value
    assert.equal(invalid.property.tenure, "");
  });

  it("seeds hmo_status with 'Pending' (C-4) and rejects spec-style 'Unknown'", () => {
    const valid = withPropertyFields({ "HMO Status": "Pending" });
    assert.equal(valid.property.hmo_status, "Pending");

    const invalid = withPropertyFields({ "HMO Status": "Unknown" });
    assert.equal(invalid.property.hmo_status, "");
  });

  it("seeds conservation_area when value is yes/no/unknown", () => {
    const yes = withPropertyFields({ "Conservation Area": "yes" });
    assert.equal(yes.property.conservation_area, "yes");

    // capitalised — should reject (per non-negotiable #4 lowercase rule)
    const cap = withPropertyFields({ "Conservation Area": "Yes" });
    assert.equal(cap.property.conservation_area, "");
  });

  it("seeds num_bedrooms when valid number, rejects negative or non-number", () => {
    assert.equal(withPropertyFields({ "Number of Bedrooms": 3 }).property.num_bedrooms, 3);
    assert.equal(withPropertyFields({ "Number of Bedrooms": 0 }).property.num_bedrooms, 0);
    assert.equal(withPropertyFields({ "Number of Bedrooms": -1 }).property.num_bedrooms, null);
    assert.equal(withPropertyFields({}).property.num_bedrooms, null);
  });
});

/* ============================================================
 * createInitialState — tenancy / landlord mode inference
 * ============================================================ */

describe("createInitialState — tenancy mode inference", () => {
  it("tenancy.mode = pick_existing when active_tenancies has entries", () => {
    const s = createInitialState({
      url_params: URL_PARAMS,
      prefill: emptyPrefillData(),
      now: NOW,
      today: TODAY,
      active_tenancies: [{ id: "recT1" }],
    });
    assert.equal(s.tenancy.mode, "pick_existing");
  });

  it("tenancy.mode = create_new when active_tenancies is empty array", () => {
    const s = createInitialState({
      url_params: URL_PARAMS,
      prefill: emptyPrefillData(),
      now: NOW,
      today: TODAY,
      active_tenancies: [],
    });
    assert.equal(s.tenancy.mode, "create_new");
  });

  it("tenancy.mode = create_new when active_tenancies is omitted", () => {
    const s = createInitialState({
      url_params: URL_PARAMS,
      prefill: emptyPrefillData(),
      now: NOW,
      today: TODAY,
    });
    assert.equal(s.tenancy.mode, "create_new");
  });
});

describe("createInitialState — landlord mode inference", () => {
  function withLandlords(landlords: LandlordRecord[]): StageAState {
    return createInitialState({
      url_params: URL_PARAMS,
      prefill: { ...emptyPrefillData(), landlords },
      now: NOW,
      today: TODAY,
    });
  }

  it("landlord.mode = pick_existing when prefill.landlords has entries", () => {
    const s = withLandlords([{ id: "recL1", fields: { Name: "ACME" } }]);
    assert.equal(s.landlord.mode, "pick_existing");
  });

  it("landlord.mode = create_new when prefill.landlords is empty", () => {
    const s = withLandlords([]);
    assert.equal(s.landlord.mode, "create_new");
  });
});

/* ============================================================
 * createInitialState — agent split (spec §11.6)
 * ============================================================ */

describe("createInitialState — agent split (spec §11.6)", () => {
  function withAgentPrefill(opts: {
    account?: AccountRecord | null;
    user?: UserRecord | null;
  }): StageAState {
    return createInitialState({
      url_params: URL_PARAMS,
      prefill: {
        ...emptyPrefillData(),
        account: opts.account ?? null,
        user: opts.user ?? null,
      },
      now: NOW,
      today: TODAY,
    });
  }

  it("agent.name and professional_body_memberships sourced from USERS row", () => {
    const s = withAgentPrefill({
      user: {
        id: "recUser1",
        fields: {
          Name: "Lloyd James",
          "Professional Body Memberships": "MARLA, NRLA",
        },
      },
    });
    assert.equal(s.agent.name, "Lloyd James");
    assert.equal(s.agent.professional_body_memberships, "MARLA, NRLA");
  });

  it("agent.company and rsw_licence_number sourced from ACCOUNTS row", () => {
    const s = withAgentPrefill({
      account: {
        id: "recAccount1",
        fields: {
          "Company Name": "Lloyd James Lettings",
          "RSW Licence": "LA-12345-67890",
        },
      },
    });
    assert.equal(s.agent.company, "Lloyd James Lettings");
    assert.equal(s.agent.rsw_licence_number, "LA-12345-67890");
  });

  it("agent fields handle null account / null user independently", () => {
    const userOnly = withAgentPrefill({
      user: { id: "recUser1", fields: { Name: "Lloyd" } },
    });
    assert.equal(userOnly.agent.name, "Lloyd");
    assert.equal(userOnly.agent.company, "");
    assert.equal(userOnly.agent.rsw_licence_number, "");

    const accountOnly = withAgentPrefill({
      account: {
        id: "recAccount1",
        fields: { "Company Name": "ACME" },
      },
    });
    assert.equal(accountOnly.agent.company, "ACME");
    assert.equal(accountOnly.agent.name, "");
  });

  it("agent fields trim whitespace from prefill values", () => {
    const s = withAgentPrefill({
      user: { id: "recUser1", fields: { Name: "  Lloyd James  " } },
      account: {
        id: "recAccount1",
        fields: { "Company Name": "  Lloyd James Lettings  " },
      },
    });
    assert.equal(s.agent.name, "Lloyd James");
    assert.equal(s.agent.company, "Lloyd James Lettings");
  });

  it("agent fields are empty strings (not undefined) when prefill values missing", () => {
    const s = withAgentPrefill({
      user: { id: "recUser1", fields: {} },
      account: { id: "recAccount1", fields: {} },
    });
    // Strict-equality guards against accidental `undefined` types
    // leaking into payload (which would serialise differently).
    assert.equal(s.agent.name, "");
    assert.equal(s.agent.company, "");
    assert.equal(s.agent.rsw_licence_number, "");
    assert.equal(s.agent.professional_body_memberships, "");
  });
});

/* ============================================================
 * Cross-cutting: prefill envelope is preserved verbatim on state
 * ============================================================ */

describe("createInitialState — prefill envelope preservation", () => {
  it("attaches the full prefill data unchanged so V2.5 components can read raw rows", () => {
    const prefill: StageAPrefillData = {
      property: {
        id: "recProp1",
        fields: {
          "Address Line 1": "12 Example Street",
          City: "Cardiff",
          Postcode: "CF10 1AA",
        },
      },
      account: { id: "recAcc1", fields: { "Company Name": "ACME" } },
      user: { id: "recUser1", fields: { Name: "Lloyd" } },
      tenancies: [],
      landlords: [],
    };
    const s = createInitialState({
      url_params: URL_PARAMS,
      prefill,
      now: NOW,
      today: TODAY,
    });
    assert.equal(s.prefill.property?.fields["Address Line 1"], "12 Example Street");
    assert.equal(s.prefill.property?.fields.City, "Cardiff");
    assert.equal(s.prefill.account?.fields["Company Name"], "ACME");
    assert.equal(s.prefill.user?.fields.Name, "Lloyd");
  });
});
