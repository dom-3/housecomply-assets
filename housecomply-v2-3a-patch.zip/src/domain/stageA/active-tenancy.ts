/**
 * Active tenancy detection — Phase 1 Spec v1.1 §6.
 *
 * A tenancy counts as "active" for the picker dropdown if:
 *   - `TENANCIES.Active === true` AND
 *   - (`TENANCIES.Contract End Date == null` OR `Contract End Date > today`)
 *
 * Plus the property linkage check — only tenancies for *this* property
 * count, even if the prefill query returns more (defence-in-depth: the
 * Make scenario should already filter, but this enforces it client-side
 * too).
 *
 * If multiple match, list ordered by `Created At` descending (most
 * recent first), with display label `<Tenant Names> · started <Contract
 * Start Date>` per spec §6.
 *
 * Pure function — no clock access. The caller injects `today` (either
 * as `Date` or as ISO date string `YYYY-MM-DD`). This deviates slightly
 * from the directive's two-arg signature (`detectActiveTenancies(all,
 * propertyId)`); the third arg is required to keep the function pure
 * and testable. See `docs/v2-3-changes.md` for the rationale.
 *
 * Source directive: V2 directive §6 V2.3.4
 */

import type { TenancyRecord } from "./prefill-types.ts";

/**
 * Convert a Date or ISO date string to the `YYYY-MM-DD` form used by
 * Airtable date-only columns. Caller-supplied values that are already
 * in that form pass through unchanged.
 */
function toIsoDate(d: Date | string): string {
  if (typeof d === "string") {
    // Trust the caller: if it's already a YYYY-MM-DD string, return as-is;
    // if it's an ISO timestamp, take the date portion.
    return d.length >= 10 ? d.slice(0, 10) : d;
  }
  // Date → YYYY-MM-DD in UTC. The Airtable date column is timezone-naive,
  // so UTC is the safe choice; using local time can cross a date boundary
  // depending on the user's timezone.
  return d.toISOString().slice(0, 10);
}

/**
 * Returns the subset of tenancies that are "active" for this property
 * as of `today`, ordered most-recently-created first.
 *
 * The function does not mutate the input array.
 *
 * @param allTenancies — unfiltered tenancy list from prefill
 * @param propertyId — Airtable record ID of the property under inspection
 * @param today — current date for the end-date comparison
 */
export function detectActiveTenancies(
  allTenancies: readonly TenancyRecord[],
  propertyId: string,
  today: Date | string,
): TenancyRecord[] {
  const todayIso = toIsoDate(today);

  const matched = allTenancies.filter((t) => {
    // Property linkage — Airtable returns linked records as a string[]
    // of record IDs, so we check membership.
    const linkedProperties = t.fields.Property ?? [];
    if (!linkedProperties.includes(propertyId)) return false;

    // Active flag — must be strictly true. Undefined / false / missing
    // disqualifies the tenancy.
    if (t.fields.Active !== true) return false;

    // End date — null/missing means "no end date set" (periodic / open),
    // so still active. A future end date is also active.
    const end = t.fields["Contract End Date"];
    if (end == null) return true;
    return end > todayIso;
  });

  // Sort by createdTime descending (most recent first). Fall back to
  // empty string if missing — those records sort to the bottom, which
  // is the correct behaviour for prefill rows that lack the metadata.
  return matched.slice().sort((a, b) => {
    const aCreated = a.createdTime ?? "";
    const bCreated = b.createdTime ?? "";
    return bCreated.localeCompare(aCreated);
  });
}

/**
 * Display label for a tenancy in the picker dropdown — per spec §6:
 * `<Tenant Names> · started <Contract Start Date>`.
 *
 * Falls back to placeholder strings when the underlying fields are
 * missing — these aren't expected in production (TENANCIES rows should
 * always have these), but keeping the function total avoids a crash
 * in the picker UI for malformed rows.
 */
export function formatTenancyLabel(t: TenancyRecord): string {
  const names = t.fields["Tenant Names"]?.trim() || "(no tenants listed)";
  const start = t.fields["Contract Start Date"]?.trim() || "(no start date)";
  return `${names} · started ${start}`;
}
