/**
 * Active tenancy detection tests — exercises Phase 1 Spec v1.1 §6 rules.
 *
 * Coverage:
 *   - Active flag filter
 *   - Contract End Date logic (null / past / future)
 *   - Property linkage filter (defence-in-depth — not relying on Make to filter)
 *   - Created-time descending ordering
 *   - `today` accepted as Date or YYYY-MM-DD string
 *   - Immutability of the input array
 *   - formatTenancyLabel formatting + fallbacks
 */

import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  detectActiveTenancies,
  formatTenancyLabel,
} from "../active-tenancy.ts";
import type { TenancyRecord } from "../prefill-types.ts";

/* ============================================================
 * Test fixtures
 * ============================================================ */

const PROPERTY_ID = "recPropertyA";
const OTHER_PROPERTY_ID = "recPropertyB";
const TODAY = "2026-05-04";

function makeTenancy(opts: {
  id: string;
  propertyId?: string;
  active?: boolean;
  contractEndDate?: string | null;
  contractStartDate?: string;
  tenantNames?: string;
  createdTime?: string;
}): TenancyRecord {
  return {
    id: opts.id,
    fields: {
      Property: opts.propertyId ? [opts.propertyId] : [PROPERTY_ID],
      Active: opts.active ?? true,
      "Contract End Date": opts.contractEndDate ?? null,
      "Contract Start Date": opts.contractStartDate ?? "2024-01-01",
      "Tenant Names": opts.tenantNames ?? "Jane Doe",
    },
    createdTime: opts.createdTime ?? "2024-01-01T10:00:00.000Z",
  };
}

/* ============================================================
 * Active flag
 * ============================================================ */

describe("detectActiveTenancies — Active flag", () => {
  it("returns empty array when given empty input", () => {
    assert.deepEqual(detectActiveTenancies([], PROPERTY_ID, TODAY), []);
  });

  it("includes a tenancy with Active === true", () => {
    const t = makeTenancy({ id: "rec1", active: true });
    const result = detectActiveTenancies([t], PROPERTY_ID, TODAY);
    assert.equal(result.length, 1);
    assert.equal(result[0]?.id, "rec1");
  });

  it("excludes a tenancy with Active === false", () => {
    const t = makeTenancy({ id: "rec1", active: false });
    assert.deepEqual(detectActiveTenancies([t], PROPERTY_ID, TODAY), []);
  });

  it("excludes a tenancy with Active === undefined (treated as not-active)", () => {
    const t: TenancyRecord = {
      id: "rec1",
      fields: {
        Property: [PROPERTY_ID],
        // Active intentionally omitted
        "Contract End Date": null,
      },
      createdTime: "2024-01-01T10:00:00.000Z",
    };
    assert.deepEqual(detectActiveTenancies([t], PROPERTY_ID, TODAY), []);
  });
});

/* ============================================================
 * Contract End Date logic
 * ============================================================ */

describe("detectActiveTenancies — Contract End Date logic", () => {
  it("includes tenancy with null end date (periodic / open)", () => {
    const t = makeTenancy({ id: "rec1", contractEndDate: null });
    const result = detectActiveTenancies([t], PROPERTY_ID, TODAY);
    assert.equal(result.length, 1);
  });

  it("includes tenancy with future end date", () => {
    const t = makeTenancy({ id: "rec1", contractEndDate: "2027-12-31" });
    const result = detectActiveTenancies([t], PROPERTY_ID, TODAY);
    assert.equal(result.length, 1);
  });

  it("excludes tenancy with past end date", () => {
    const t = makeTenancy({ id: "rec1", contractEndDate: "2025-12-31" });
    assert.deepEqual(detectActiveTenancies([t], PROPERTY_ID, TODAY), []);
  });

  it("excludes tenancy with end date EQUAL to today (must be strictly greater)", () => {
    // Spec §6: "Contract End Date > today" — strict.
    const t = makeTenancy({ id: "rec1", contractEndDate: TODAY });
    assert.deepEqual(detectActiveTenancies([t], PROPERTY_ID, TODAY), []);
  });
});

/* ============================================================
 * Property linkage filter
 * ============================================================ */

describe("detectActiveTenancies — property linkage", () => {
  it("excludes tenancy linked to a different property", () => {
    const t = makeTenancy({ id: "rec1", propertyId: OTHER_PROPERTY_ID });
    assert.deepEqual(detectActiveTenancies([t], PROPERTY_ID, TODAY), []);
  });

  it("excludes tenancy with empty Property link array", () => {
    const t: TenancyRecord = {
      id: "rec1",
      fields: { Property: [], Active: true, "Contract End Date": null },
      createdTime: "2024-01-01T10:00:00.000Z",
    };
    assert.deepEqual(detectActiveTenancies([t], PROPERTY_ID, TODAY), []);
  });

  it("excludes tenancy with missing Property field", () => {
    const t: TenancyRecord = {
      id: "rec1",
      fields: { Active: true, "Contract End Date": null },
      createdTime: "2024-01-01T10:00:00.000Z",
    };
    assert.deepEqual(detectActiveTenancies([t], PROPERTY_ID, TODAY), []);
  });

  it("includes tenancy linked to multiple properties if our property is one of them", () => {
    const t: TenancyRecord = {
      id: "rec1",
      fields: {
        Property: [OTHER_PROPERTY_ID, PROPERTY_ID],
        Active: true,
        "Contract End Date": null,
      },
      createdTime: "2024-01-01T10:00:00.000Z",
    };
    const result = detectActiveTenancies([t], PROPERTY_ID, TODAY);
    assert.equal(result.length, 1);
  });
});

/* ============================================================
 * Ordering by createdTime descending
 * ============================================================ */

describe("detectActiveTenancies — ordering", () => {
  it("orders multiple matches by createdTime descending (most recent first)", () => {
    const tOld = makeTenancy({
      id: "recOld",
      createdTime: "2023-01-01T10:00:00.000Z",
    });
    const tNew = makeTenancy({
      id: "recNew",
      createdTime: "2025-06-15T10:00:00.000Z",
    });
    const tMid = makeTenancy({
      id: "recMid",
      createdTime: "2024-03-01T10:00:00.000Z",
    });

    const result = detectActiveTenancies(
      [tOld, tNew, tMid],
      PROPERTY_ID,
      TODAY,
    );
    assert.deepEqual(
      result.map((t) => t.id),
      ["recNew", "recMid", "recOld"],
    );
  });

  it("places tenancies with missing createdTime at the bottom", () => {
    const tWith = makeTenancy({
      id: "recWith",
      createdTime: "2024-01-01T10:00:00.000Z",
    });
    const tWithout: TenancyRecord = {
      id: "recWithout",
      fields: {
        Property: [PROPERTY_ID],
        Active: true,
        "Contract End Date": null,
      },
      // createdTime omitted
    };
    const result = detectActiveTenancies(
      [tWithout, tWith],
      PROPERTY_ID,
      TODAY,
    );
    assert.equal(result[0]?.id, "recWith");
    assert.equal(result[1]?.id, "recWithout");
  });
});

/* ============================================================
 * `today` argument flexibility
 * ============================================================ */

describe("detectActiveTenancies — today argument", () => {
  it("accepts today as a YYYY-MM-DD string", () => {
    const t = makeTenancy({ id: "rec1", contractEndDate: "2027-01-01" });
    const result = detectActiveTenancies([t], PROPERTY_ID, "2026-05-04");
    assert.equal(result.length, 1);
  });

  it("accepts today as a Date object (UTC date extracted)", () => {
    const t = makeTenancy({ id: "rec1", contractEndDate: "2027-01-01" });
    const today = new Date("2026-05-04T12:00:00.000Z");
    const result = detectActiveTenancies([t], PROPERTY_ID, today);
    assert.equal(result.length, 1);
  });

  it("accepts today as a full ISO timestamp string (date portion extracted)", () => {
    const t = makeTenancy({ id: "rec1", contractEndDate: "2027-01-01" });
    const result = detectActiveTenancies(
      [t],
      PROPERTY_ID,
      "2026-05-04T12:00:00.000Z",
    );
    assert.equal(result.length, 1);
  });
});

/* ============================================================
 * Immutability
 * ============================================================ */

describe("detectActiveTenancies — immutability", () => {
  it("does not mutate the input array", () => {
    const tA = makeTenancy({
      id: "recA",
      createdTime: "2023-01-01T00:00:00.000Z",
    });
    const tB = makeTenancy({
      id: "recB",
      createdTime: "2025-01-01T00:00:00.000Z",
    });
    const input: readonly TenancyRecord[] = [tA, tB];
    const inputSnapshot = [...input];

    detectActiveTenancies(input, PROPERTY_ID, TODAY);

    // Compare by reference — input array order is unchanged.
    assert.deepEqual(input, inputSnapshot);
    assert.equal(input[0], tA);
    assert.equal(input[1], tB);
  });
});

/* ============================================================
 * formatTenancyLabel
 * ============================================================ */

describe("formatTenancyLabel", () => {
  it("formats as `<Tenant Names> · started <Contract Start Date>`", () => {
    const t = makeTenancy({
      id: "rec1",
      tenantNames: "Jane Doe, John Doe",
      contractStartDate: "2026-01-15",
    });
    assert.equal(
      formatTenancyLabel(t),
      "Jane Doe, John Doe · started 2026-01-15",
    );
  });

  it("falls back to placeholders when fields are missing", () => {
    const t: TenancyRecord = {
      id: "rec1",
      fields: { Property: [PROPERTY_ID], Active: true },
    };
    assert.equal(
      formatTenancyLabel(t),
      "(no tenants listed) · started (no start date)",
    );
  });

  it("trims whitespace in tenant names and start date", () => {
    const t = makeTenancy({
      id: "rec1",
      tenantNames: "  Jane Doe  ",
      contractStartDate: "  2026-01-15  ",
    });
    assert.equal(
      formatTenancyLabel(t),
      "Jane Doe · started 2026-01-15",
    );
  });
});
