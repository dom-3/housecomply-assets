/**
 * Stage A pre-fill data shapes — Airtable record types.
 *
 * These represent the rows fetched from Airtable during the Stage A
 * pre-fill step (spec §2.3 step 5): PROPERTIES, ACCOUNTS, USERS,
 * TENANCIES, LANDLORDS. The shapes are deliberately minimal — they cover
 * what V2.3 (initial state factory + active tenancy detection) and V2.4
 * (prefill service) need today, and are expected to be refined in V2.4
 * when the actual Airtable / Make-prefill-scenario fetch lands.
 *
 * Field names mirror Airtable column names verbatim (with quoting for
 * spaces) — they are NOT renamed to snake_case here. The translation
 * from Airtable-cased field names to snake_case payload keys happens in
 * the V2.6 payload builder, not here.
 *
 * Source:
 *   - Phase 1 Spec v1.1 §2.3 (page lifecycle / fetches)
 *   - production `inspect-stage-a.js` (which uses the same field names
 *     for its parallel-fetch pre-fill at lines 211–221, 240–289)
 */

import type {
  PropertyType,
  ConstructionType,
  AgeBand,
  ListedStatus,
  Tenure,
  HmoStatus,
} from "./constants.ts";

/**
 * Common Airtable record envelope: every row has an `id` (e.g. "rec...")
 * and a `fields` map of column-name → value.
 *
 * `fields` values are typed loosely (string | number | boolean | string[]
 * | undefined) because Airtable returns missing optional columns as
 * undefined, and link-typed columns as string[] of record IDs. Per-record
 * shapes below narrow the keys we care about.
 */
export interface AirtableRecord<F> {
  id: string;
  fields: F;
  /** Airtable's createdTime per row, ISO 8601. */
  createdTime?: string;
}

/* ============================================================
 * PROPERTIES row
 * ============================================================ */

export interface PropertyRecordFields {
  /** Address fields — read-only on the Stage A form (locked decision §11.1). */
  "Address Line 1"?: string;
  /** Legacy alias for Address Line 1 — production JS has a fallback. */
  Address?: string;
  City?: string;
  County?: string;
  Postcode?: string;
  Country?: string;

  /** Editable fields — seeded from these values, refinable on form. */
  "Property Type"?: PropertyType | string;
  "Construction Type"?: ConstructionType | string;
  "Age Band"?: AgeBand | string;
  "Listed Status"?: ListedStatus | string;
  /** "yes" / "no" / "unknown" stored as string in Airtable. */
  "Conservation Area"?: string;
  Tenure?: Tenure | string;
  "HMO Status"?: HmoStatus | string;
  "Number of Bedrooms"?: number;
}

export type PropertyRecord = AirtableRecord<PropertyRecordFields>;

/* ============================================================
 * ACCOUNTS row
 * ============================================================ */

export interface AccountRecordFields {
  "Company Name"?: string;
  "RSW Licence"?: string;
}

export type AccountRecord = AirtableRecord<AccountRecordFields>;

/* ============================================================
 * USERS row
 * ============================================================ */

export interface UserRecordFields {
  Name?: string;
  /** Schema addition per Phase 1 Spec §13.2 (locked, deferred to v3.1
   * if Airtable hasn't shipped it yet — V2.4 will handle absence). */
  "Professional Body Memberships"?: string;
  /** Linked record IDs of the Account(s) this user belongs to.
   * Used for the §2.3 step 2 account-user defence-in-depth check. */
  Account?: string[];
}

export type UserRecord = AirtableRecord<UserRecordFields>;

/* ============================================================
 * TENANCIES row
 * ============================================================ */

export interface TenancyRecordFields {
  Active?: boolean;
  /** Linked record IDs of the Property this tenancy belongs to. */
  Property?: string[];
  /** ISO date "YYYY-MM-DD". null/missing = no end date (periodic / open). */
  "Contract End Date"?: string | null;
  "Contract Start Date"?: string;
  /** Per amendment A-01 — date the contract holder takes possession.
   * Distinct from Contract Start Date (the contract-signing date). */
  "Occupation Start Date"?: string;
  "Tenant Names"?: string;
  /** Number of contract holders. */
  "Number of Tenants"?: number;
}

export type TenancyRecord = AirtableRecord<TenancyRecordFields>;

/* ============================================================
 * LANDLORDS row
 * ============================================================ */

export interface LandlordRecordFields {
  Name?: string;
  "RSW Registration Number"?: string;
  Email?: string;
  Phone?: string;
  /** Linked record IDs of the Account this landlord is associated with. */
  Account?: string[];
}

export type LandlordRecord = AirtableRecord<LandlordRecordFields>;

/* ============================================================
 * Aggregated prefill response shape
 * ============================================================ */

/**
 * The full set of records fetched at Stage A page load. Returned (in
 * V2.4) by the dedicated `HC_Scenario_StageA_Prefill` Make scenario,
 * synthesised here for V2.3's state-factory tests.
 *
 * `tenancies` is the unfiltered list returned by Airtable; the active
 * filter (per spec §6) is applied by `detectActiveTenancies` at render
 * time, not at fetch time, so the inspector can switch picker mode
 * without re-fetching.
 */
export interface StageAPrefillData {
  property: PropertyRecord | null;
  account: AccountRecord | null;
  user: UserRecord | null;
  tenancies: TenancyRecord[];
  landlords: LandlordRecord[];
}

/**
 * Empty prefill — useful as a default for tests and for the initial
 * "loading" boot state.
 */
export function emptyPrefillData(): StageAPrefillData {
  return {
    property: null,
    account: null,
    user: null,
    tenancies: [],
    landlords: [],
  };
}
